export const PLUGIN_ID = 'testPlugin';
export const PLUGIN_NAME = 'testPlugin';
